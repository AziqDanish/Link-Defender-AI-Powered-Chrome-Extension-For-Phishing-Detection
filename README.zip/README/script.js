const steps = [
{
title: "Download Your Extension",
description: "Download the Link Defender Chrome Extension files to your computer.",
instruction: "Choose the latest version to download.",
image: "images/step1.png"
},
{
title: "Extract the ZIP File",
description: "Extract the downloaded ZIP file.",
instruction: "Right-click the ZIP file and select Extract All.",
image: "images/step2.png"
},
{
title: "Open Google Chrome",
description: "Open Google Chrome on your computer.",
instruction: "Launch Google Chrome to begin the installation.",
image: "images/step3.png"
},
{
title: "Open Extensions Page",
description: "Open the Chrome Extensions management page.",
instruction: "You can find it at top right corner.",
image: "images/step4.png"
},
{
title: "Extension",
description: "Setup Extension.",
instruction: "Find and click Extension. ",
image: "images/step5.png"
},
{
title: "Manage Extension",
description: "Setup Extension.",
instruction: "Click Manage Extension.",
image: "images/step6.png"
},
{
title: "Enable Developer Mode",
description: "Enable Developer Mode to install a local extension.",
instruction: "Turn ON the Developer mode switch at the top-right.",
image: "images/step7.png"
},
{
title: "Find Load Unpacked",
description: "Find the Load unpacked button.",
instruction: "Look for Load unpacked near the top-left of the Extensions page.",
image: "images/step8.png"
},
{
title: "Select Extension Folder",
description: "Select your Link Defender extension folder.",
instruction: "Choose the folder containing your extension files.",
image: "images/step9.png"
},
{
title: "Open Extension Details",
description: "Open the details page for Link Defender.",
instruction: "find puzzle like icon at the top right corner.",
image: "images/step10.png"
},
{
title: "Pin Link Defender",
description: "Pin Link Defender to the Chrome toolbar.",
instruction: "Open the Extensions menu and click the pin icon.",
image: "images/step11.png"
},
{
title: "Open Extension Options",
description: "Setup options for Link Defender.",
instruction: "Right click link defender and then click options.",
image: "images/step12.png"
},
{
title: "Setting API VirusTotal",
description: "Setup API VirusTotal",
instruction: "Click the hyperlink provide",
image: "images/step13.png"
},
{
title: "Login VirusTotal",
description: "Create Account For VirusTotal",
instruction: "Sign-Up VirusTotal to get API",
image: "images/step14.png"
},
{
title: "Enter Website VirusTotal",
description: "Enter a website URL that you want to get API.",
instruction: "Click API key.",
image: "images/step15.png"
},
{
title: "VirusTotal API Key",
description: "Get VirusTotal API key",
instruction: "Copy the API key from VirusTotal",
image: "images/step16.png"
},
{
title: "Setup VirusTotal API Key",
description: "Paste the VirusTotal API Key",
instruction: "Paste the key in the form.",
image: "images/step17.png"
},
{
title: "Setting API Gemini AI",
description: "Setup API Gemini AI.",
instruction: "Click the hyperlink provide.",
image: "images/step18.png"
},
{
title: "Enter Website Gemini AI",
description: "Enter a website URL that you want to get API.",
instruction: "Click link at the top left corner.",
image: "images/step19.png"
},
{
title: "Gemini AI API Key",
description: "Get Gemini AI API key.",
instruction: "Copy the API key from Gemini AI.",
image: "images/step20.png"
},
{
title: "Setup Gemini AI API Key",
description: "Paste the Gemini AI API Key.",
instruction: "Paste the key in the form.",
image: "images/step21.png"
},
{
title: "Setting Token and Group ID Telegram",
description: "Setup Token and Group ID Telegram.",
instruction: "Click the hyperlink provide.",
image: "images/step22.png"
},
{
title: "Enter Website Telegram Link Defender",
description: "Enter a website Telergam that you want to get Token and Group ID.",
instruction: "Click View In Telegram.",
image: "images/step23.png"
},
{
title: "Token and Group ID Telegram",
description: "Get Token and Group ID Telegram.",
instruction: "Copy the Token and Group ID key from Telegram.",
image: "images/step24.png"
},
{
title: "Setup Token and Group ID Telegram",
description: "Paste the Setup Token and Group ID.",
instruction: "Paste the Token and Group ID in the form and click sent test message.",
image: "images/step25.png"
},
{
title: "Verify Connection",
description: "Make sure connection is online.",
instruction: "Check group Telegram Link defender to verify.",
image: "images/step26.png"
},
{
title: "Scan Cache",
description: "Link defender save link cache that are safe.",
instruction: "Click this button to clear safe link cache (optional).",
image: "images/step27.png"
},
{
title: "Setup Complete",
description: "Your Link Defender Chrome Extension setup is complete.",
instruction: "Your extension is now ready to use.",
image: "images/step28.png"
}
];

// =========================
// CURRENT STEP
// =========================

let currentStep = 1;

// =========================
// GET ELEMENTS
// =========================

const stepNumber = document.getElementById("stepNumber");
const progressPercent = document.getElementById("progressPercent");
const progress = document.getElementById("progress");
const currentStepText = document.getElementById("currentStep");
const stepTitle = document.getElementById("stepTitle");
const stepDescription = document.getElementById("stepDescription");
const stepInstruction = document.getElementById("stepInstruction");
const stepImage = document.getElementById("stepImage");
const previousBtn = document.getElementById("previousBtn");
const nextBtn = document.getElementById("nextBtn");
const stepItems = document.querySelectorAll(".step-item");

// =========================
// UPDATE TUTORIAL
// =========================

function updateTutorial() {


const step = steps[currentStep - 1];

if (!step) {
    return;
}

const percent = Math.round(
    (currentStep / steps.length) * 100
);

stepNumber.textContent =
    "Step " + currentStep + " of " + steps.length;

progressPercent.textContent =
    percent + "%";

currentStepText.textContent =
    currentStep;

stepTitle.textContent =
    step.title;

stepDescription.textContent =
    step.description;

stepInstruction.textContent =
    step.instruction;

progress.style.width =
    percent + "%";

stepImage.src =
    step.image;

stepImage.alt =
    "Step " + currentStep + " screenshot";


// Previous button

if (currentStep === 1) {

    previousBtn.disabled = true;
    previousBtn.style.opacity = "0.4";
    previousBtn.style.cursor = "not-allowed";

} else {

    previousBtn.disabled = false;
    previousBtn.style.opacity = "1";
    previousBtn.style.cursor = "pointer";

}


// Next button

if (currentStep === steps.length) {

    nextBtn.innerHTML =
        'Finish <i class="fa-solid fa-check"></i>';

} else {

    nextBtn.innerHTML =
        'Next <i class="fa-solid fa-arrow-right"></i>';

}


// Active step

stepItems.forEach(function(item, index) {

    if (index === currentStep - 1) {
        item.classList.add("active");
    } else {
        item.classList.remove("active");
    }

});


}

// =========================
// NEXT
// =========================

function nextStep() {


if (currentStep < steps.length) {

    currentStep++;

    updateTutorial();

} else {

    alert(
        "Tutorial completed! Your Link Defender Chrome Extension is ready."
    );

}


}

// =========================
// PREVIOUS
// =========================

function previousStep() {


if (currentStep > 1) {

    currentStep--;

    updateTutorial();

}


}

// =========================
// GO TO STEP
// =========================

function goToStep(step) {


if (step >= 1 && step <= steps.length) {

    currentStep = step;

    updateTutorial();

}


}

// =========================
// START TUTORIAL
// =========================

function startTutorial() {


currentStep = 1;

updateTutorial();

document.getElementById("tutorial").scrollIntoView({
    behavior: "smooth"
});


}

// =========================
// START
// =========================

updateTutorial();
